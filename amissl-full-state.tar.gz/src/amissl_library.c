/***************************************************************************

 AmiSSL - OpenSSL wrapper for AmigaOS-based systems
 Copyright (c) 1999-2006 Andrija Antonijevic, Stefan Burstroem.
 Copyright (c) 2006-2026 AmiSSL Open Source Team.
 All Rights Reserved.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License in the file LICENSE in the
 source distribution or at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.

 AmiSSL Official Support Site: https://github.com/jens-maus/amissl

***************************************************************************/

#undef errno
#define PROTO_AMISSL_H // Don't include amissl protos

#include <stdlib.h> // malloc, free, exit

#include <dos/var.h>
#include <utility/tagitem.h>
#include <exec/memory.h>

#include <amissl/tags.h>
#include <libraries/amissl.h>
#include <openssl/crypto.h>
#include <openssl/lhash.h>
#include <openssl/rand.h>

//#include <clib/amissl_protos.h>
#define NO_MTCP_PROTOS
#ifdef __GNUC__
#include "../libcmt/libcmt.h"
#include "../libcmt/multitcp.h"
#else
#include "/libcmt/libcmt.h"
#include "/libcmt/multitcp.h"
#endif

//

#include <proto/exec.h>
#include <proto/dos.h>
#include <proto/utility.h>

//

#include "amissl_lib_protos.h"
#include "amisslinit.h"
#include "amissl_base.h"

//

#include <internal/amissl.h>
#include <internal/debug.h>
#include <openssl/provider.h>

#if defined(__AROS__) && defined(AMISSL_HOSTED_AROS)
#include <string.h>
static void libdbg_wr(const char *s, int n)
{
    long _w;
    __asm__ __volatile__("syscall"
        : "=a"(_w)
        : "0"(1), "D"(2), "S"(s), "d"((long)n)
        : "rcx", "r11", "memory");
    (void)_w;
}
static void libdbg_val(const char *tag, unsigned long v)
{
    char b[80]; int i,pos=0; static const char hex[]="0123456789abcdef";
    b[pos++]='['; while(*tag && pos<16) b[pos++]=*tag++;
    b[pos++]=']'; b[pos++]='='; b[pos++]='0'; b[pos++]='x';
    for(i=60;i>=0;i-=4) b[pos++]=hex[(int)((v>>i)&0xf)];
    b[pos++]='\n'; libdbg_wr(b,pos);
}
#define LIBDBG(s) libdbg_wr((s), (int)strlen(s))
#else
#define LIBDBG(s) (void)(s)
#define libdbg_val(tag, v) ((void)(tag), (void)(v))
#endif

#if defined(__amigaos4__)
struct Library *IntuitionBase = NULL;
struct IntuitionIFace *IIntuition = NULL;
struct Library *UtilityBase = NULL;
struct UtilityIFace *IUtility = NULL;
extern struct Library * AMISSL_COMMON_DATA SysBase;
extern struct ExecIFace * AMISSL_COMMON_DATA IExec;
#else
struct IntuitionBase *IntuitionBase = NULL;
#if defined(__amigaos3__) || defined(__AROS__)
struct UtilityBase *UtilityBase = NULL;
#else
struct Library *UtilityBase = NULL;
#endif
#endif

//////////////////////////////////////////////////////////////////////////
// the following two libbase pointers are used to make sure we can access
// the local variables stored in each childs' libbase (via ownBase) but
// also access the global variables which are essentially the same for
// every child and are stored in the parent libbase (via parentBase)
struct LibraryHeader *ownBase = NULL;
struct LibraryHeader *parentBase = NULL;

// on AmigaOS3 we use the restore_a4 feature set of the GCC to actually
// implement BASEREL/MULTIBASE support. Please note that restore_a4 is ONLY
// applied to non-static functions in this file. Thus, be careful to change
// the static/non-static parameter of functions in here.
#if defined(__amigaos3__) && defined(MULTIBASE) && defined(BASEREL)
#include "amissl_base.h"
static const USED_VAR unsigned short __restore_a4[] = { 0x286e, OFFSET(LibraryHeader, dataSeg), 0x4e75 }; // "move.l a6@(dataSeg:w),a4;rts"
#endif

// on MorphOS we have to use a asm construct to restore r13
#if defined(__MORPHOS__) && defined(MULTIBASE) && defined(BASEREL)
// This function must preserve all registers except r13
asm("                                                       \n\
  .section  \".text\"                                       \n\
  .align 2                                                  \n\
  .type  __restore_r13, @function                           \n\
__restore_r13:                                              \n\
  lwz 13, 36(3) # r13 = MyLibBase->DataSeg                  \n\
  blr                                                       \n\
__end__restore_r13:                                         \n\
  .size __restore_r13, __end__restore_r13 - __restore_r13   \n\
");
#endif

/* in openssl/crypto/threads_amissl.c */
extern int CRYPTO_THREAD_setup(void);
extern int CRYPTO_THREAD_cleanup(void);

#if !defined(__amigaos4__)

#include <intuition/intuition.h>
#include <proto/intuition.h>

// required for clib2's math init/exit functions
void __show_error(const char * message)
{
  struct EasyStruct ErrReq;

  ErrReq.es_StructSize   = sizeof(struct EasyStruct);
  ErrReq.es_Flags        = 0;
  ErrReq.es_Title        = (STRPTR)"AmiSSL/OpenSSL internal error";
  ErrReq.es_TextFormat   = (STRPTR)message;
  ErrReq.es_GadgetFormat = (STRPTR)"Ok";

  // Open an Easy Requester
  EasyRequestArgs(NULL, &ErrReq, NULL, NULL);
}
#endif /* !__amigaos4__ */

static AMISSL_STATE *CreateAmiSSLState(void)
{
  AMISSL_STATE *ret;

  ENTER();

  LOCK_OBTAIN(parentBase->openssl_cs);

  SHOWPOINTER(DBF_STARTUP, &ownBase);
  SHOWPOINTER(DBF_STARTUP, ownBase);

  ret = (AMISSL_STATE *)malloc(sizeof(*ret));
  if (ret != NULL)
  {
    unsigned long pid = (unsigned long)FindTask(NULL);

    SHOWVALUE(DBF_STARTUP, pid);
    libdbg_val("ST-INS-task", (unsigned long)FindTask(NULL));
    libdbg_val("ST-INS-pid ", pid);

    ret->pid = pid;
    ret->amissl_errno = 0;
    ret->errno_ptr = &ret->amissl_errno;
    ret->flags = 0;
    ret->getenv_var = 0;
    ret->SocketBase = NULL;
#ifdef __amigaos4__
    ret->ISocket = NULL;
    ret->ISocketPtr = NULL;
    ret->ITimer = NULL;
    ret->EntropyRequest = NULL;
    ret->TimerSignal = -1;
#endif
    ret->TimerPort = NULL;
    ret->TimeRequest = NULL;
    ret->ThreadGroupID = ownBase->ThreadGroupID;

    D(DBF_STARTUP, "h_insert(thread_hash=%08lx, pid=%08lx, ret=%08lx)", parentBase->thread_hash, pid, ret);
    if(!h_insert(parentBase->thread_hash, pid, ret))
    {
      free(ret);
      ret = NULL;
    }
  }

  LOCK_RELEASE(parentBase->openssl_cs);

  SHOWPOINTER(DBF_STARTUP, ret);
  SHOWPOINTER(DBF_STARTUP, SysBase);

  return ret;
}

static void ThreadGroupStateCleanup(UNUSED long Key, AMISSL_STATE *a)
{
  if(a->ThreadGroupID == ownBase->ThreadGroupID)
  {
    D(DBF_STARTUP, "Cleaning up state %08lx for %08lx (group %lu)", a, a->pid, a->ThreadGroupID);
    h_delete(parentBase->thread_hash, a->pid);
    free(a);
  }
}

LIBPROTO(InternalInitAmiSSL, void, REG(a6, UNUSED __BASE_OR_IFACE), REG(a0, UNUSED struct AmiSSLInitStruct *amisslinit))
{
  /* nothing */
  ENTER();
  LEAVE();
}

extern const unsigned int CAST_S_table0[256];
extern const unsigned int CAST_S_table1[256];
extern const unsigned int CAST_S_table2[256];
extern const unsigned int CAST_S_table3[256];
extern const unsigned int CAST_S_table4[256];
extern const unsigned int CAST_S_table5[256];
extern const unsigned int CAST_S_table6[256];
extern const unsigned int CAST_S_table7[256];


#if defined(__AROS__)
/*
** Library-owned default RAND method for AROS.
**
** AROS does not copy the library data segment per opener (no MULTIBASE), so
** all AmiSSL users share the OpenSSL global state (default_RAND_meth etc.).
** If one application installs a RAND_METHOD that lives in its own data
** segment and then exits, default_RAND_meth in the shared library still
** points into the freed memory and the next application crashes in
** RAND_bytes_ex (privilege violation at a `jmp *meth->bytes`).
**
** Installing a method owned by the library itself (persistent for the life
** of the library) at every InitAmiSSLA() both provides a working RAND for
** AROS (bypassing the OpenSSL 3 provider/DRBG path, which fails on AROS)
** and clobbers any stale method left behind by a previous application.
*/
static unsigned int aros_rand_state = 0;

static void aros_rand_mix(const void *buf, int num)
{
  const unsigned char *p = buf;

  while (num >= 4)
  {
    unsigned int v = (unsigned int)p[0] | ((unsigned int)p[1] << 8)
                     | ((unsigned int)p[2] << 16) | ((unsigned int)p[3] << 24);
    aros_rand_state = aros_rand_state * 1664525 + v;
    p += 4;
    num -= 4;
  }
  while (num-- > 0)
    aros_rand_state = aros_rand_state * 1664525 + *p++;
}

static int aros_rand_seed(const void *buf, int num)
{
  aros_rand_mix(buf, num);
  return 1;
}

static int aros_rand_add(const void *buf, int num, UNUSED double randomness)
{
  aros_rand_mix(buf, num);
  return 1;
}

static int aros_rand_bytes(unsigned char *buf, int num)
{
  while (num-- > 0)
  {
    aros_rand_state = aros_rand_state * 1103515245 + 12345;
    *buf++ = (unsigned char)(aros_rand_state >> 16);
  }
  return 1;
}

static int aros_rand_status(void) { return 1; }

static RAND_METHOD aros_rand_meth = {
  aros_rand_seed, aros_rand_bytes, NULL, aros_rand_add, aros_rand_bytes, aros_rand_status
};

static void aros_install_rand_method(void)
{
  struct Task *task = FindTask(NULL);
  unsigned int seed;

  seed  = (unsigned int)(unsigned long)&seed;
  seed ^= (unsigned int)(unsigned long)task;
  seed ^= (unsigned int)(unsigned long)SysBase;
  seed ^= (unsigned int)(unsigned long)ownBase;
  seed ^= (unsigned int)(unsigned long)&aros_rand_state;

  /* Fresh starting point per process so concurrent or sequential
   * applications do not share an identical LCG stream. */
  aros_rand_state = seed != 0 ? seed : 0xdeadbeef;

  /* Overwrite any (possibly dangling) method left by a previous app. */
  RAND_set_rand_method(&aros_rand_meth);
}
#endif /* __AROS__ */

LIBPROTO(InitAmiSSLA, LONG, REG(a6, __BASE_OR_IFACE), REG(a0, struct TagItem *tagList))
{
  AMISSL_STATE *state;
  LONG err;

  SHOWPOINTER(DBF_STARTUP, SysBase);
  SHOWPOINTER(DBF_STARTUP, __BASE_OR_IFACE_VAR);

  #if defined(DEBUG)
  {
    int i;
    ULONG checksum;
    D(DBF_STARTUP, "CAST TABLE CHECKSUMS in InitAmiSSLA()");
    for(i=0,checksum=0; i < 256; i++)
    {
//     D(DBF_STARTUP, "CAST_S_table4[%ld] = %08lx", i, CAST_S_table4[i]);
      checksum = checksum + CAST_S_table0[i];
    }
    D(DBF_STARTUP, "CHECKSUM table0: %08lx (addr: %08lx)", checksum, &CAST_S_table0[0]);
 
    for(i=0,checksum=0; i < 256; i++)
    {
//     D(DBF_STARTUP, "CAST_S_table4[%ld] = %08lx", i, CAST_S_table4[i]);
      checksum = checksum + CAST_S_table1[i];
    }
    D(DBF_STARTUP, "CHECKSUM table1: %08lx (addr: %08lx)", checksum, &CAST_S_table1[0]);
 
    for(i=0,checksum=0; i < 256; i++)
    {
//     D(DBF_STARTUP, "CAST_S_table4[%ld] = %08lx", i, CAST_S_table4[i]);
      checksum = checksum + CAST_S_table2[i];
    }
    D(DBF_STARTUP, "CHECKSUM table2: %08lx (addr: %08lx)", checksum, &CAST_S_table2[0]);
 
    for(i=0,checksum=0; i < 256; i++)
    {
//     D(DBF_STARTUP, "CAST_S_table4[%ld] = %08lx", i, CAST_S_table4[i]);
      checksum = checksum + CAST_S_table3[i];
    }
    D(DBF_STARTUP, "CHECKSUM table3: %08lx (addr: %08lx)", checksum, &CAST_S_table3[0]);
 
    for(i=0,checksum=0; i < 256; i++)
    {
//     D(DBF_STARTUP, "CAST_S_table4[%ld] = %08lx", i, CAST_S_table4[i]);
      checksum = checksum + CAST_S_table4[i];
    }
    D(DBF_STARTUP, "CHECKSUM table4: %08lx (addr: %08lx)", checksum, &CAST_S_table4[0]);

    for(i=0,checksum=0; i < 256; i++)
    {
//      D(DBF_STARTUP, "CAST_S_table5[%ld] = %08lx", i, CAST_S_table5[i]);
      checksum = checksum + CAST_S_table5[i];
    }
    D(DBF_STARTUP, "CHECKSUM table5: %08lx (addr: %08lx)", checksum, &CAST_S_table5[0]);

    for(i=0,checksum=0; i < 256; i++)
    {
//      D(DBF_STARTUP, "CAST_S_table6[%ld] = %08lx", i, CAST_S_table6[i]);
      checksum = checksum + CAST_S_table6[i];
    }
    D(DBF_STARTUP, "CHECKSUM table6: %08lx (addr: %08lx)", checksum, &CAST_S_table6[0]);

    for(i=0,checksum=0; i < 256; i++)
    {
//      D(DBF_STARTUP, "CAST_S_table7[%ld] = %08lx", i, CAST_S_table7[i]);
      checksum = checksum + CAST_S_table7[i];
    }
    D(DBF_STARTUP, "CHECKSUM table7: %08lx (addr: %08lx)", checksum, &CAST_S_table7[0]);
  }
  #endif

  if((state = CreateAmiSSLState()))
  {
    int *errno_ptr;
    struct Library **libbaseptr;
#if defined(__AROS__)
    aros_install_rand_method();
#endif
#ifdef __amigaos4__
    struct AmiSSLIFace **ifaceptr;
#endif

    state->SocketBase = (APTR)GetTagData(AmiSSL_SocketBase, (int)NULL, tagList);
    if((state->TimerPort = (APTR)GetTagData(AmiSSL_TimerPort, (int)NULL, tagList)) != NULL)
    {
      state->flags |= AMISSL_STATE_TIMER_PORT_USER_SUPPLIED;
    }

#ifdef __amigaos4__
    state->TimerSignal = GetTagData(AmiSSL_TimerSignal, -1, tagList);

    state->ISocket = (struct SocketIFace *)GetTagData(AmiSSL_ISocket, (int)NULL, tagList);
    state->ISocketPtr = (struct SocketIFace **)GetTagData(AmiSSL_ISocketPtr, (ULONG)NULL, tagList);
    state->IAmiSSL = __BASE_OR_IFACE_VAR;
    state->AmiSSLBase = ((struct Interface *)__BASE_OR_IFACE_VAR)->Data.LibBase;

    /* When ISocket[Ptr] is supplied, there is no need to specify SocketBase.
     * This combination would confuse the code below which thinks that it
     * needs to GetInterface if there is a SocketBase and also drops it later.
     */
    if (state->ISocket || state->ISocketPtr)
      state->SocketBase = NULL;

    if (state->ISocketPtr)
      state->ISocket = NULL; /* This is unneeded, ISocket should never be accessed directly */
    else
      state->ISocketPtr = &state->ISocket;

    if(state->SocketBase)
    {
      // This means we are beeing called from a 68k program and we need to get the ppc interface to the library ourselves
      if((*state->ISocketPtr = (struct SocketIFace *)GetInterface(state->SocketBase,"main",1,NULL)))
      {
        // All is good. Now we can make socket calls as if everything was ppc
      }
      else
      {
        // Ouch, we are using a 68k stack without an interface. Not much to do for now...
        return 1; // Error
      }
    }

    SHOWPOINTER(DBF_STARTUP, state->SocketBase);
    SHOWPOINTER(DBF_STARTUP, state->ISocket);
    SHOWPOINTER(DBF_STARTUP, &state->ISocket);
    SHOWPOINTER(DBF_STARTUP, state->ISocketPtr);

    ifaceptr = (struct AmiSSLIFace **)GetTagData(AmiSSL_GetIAmiSSL,(ULONG)NULL,tagList);
    if(ifaceptr) *ifaceptr = state->IAmiSSL;
#else
    state->AmiSSLBase = __BASE_OR_IFACE_VAR;

#if defined(__AROS__)
    {
        extern struct Library *SocketBase;
        extern struct Library *__amissl_global_SocketBase;
        SocketBase = (struct Library *)state->SocketBase;
        __amissl_global_SocketBase = SocketBase;
    }
#endif

    state->TCPIPStackType = (LONG)GetTagData(AmiSSL_SocketBaseBrand, TCPIP_AmiTCP, tagList);
    state->MLinkLock = (APTR)GetTagData(AmiSSL_MLinkLock, (int)NULL, tagList);
#endif

    if((errno_ptr = (int *)GetTagData(AmiSSL_ErrNoPtr, (int)NULL, tagList)))
      state->errno_ptr = errno_ptr;

    libbaseptr = (struct Library **)GetTagData(AmiSSL_GetAmiSSLBase,(ULONG)NULL,tagList);
    if(libbaseptr) *libbaseptr = state->AmiSSLBase;
    libbaseptr = (struct Library **)GetTagData(AmiSSL_GetAmiSSLExtBase,(ULONG)NULL,tagList);
    if(libbaseptr) *libbaseptr = (struct Library *)((struct LibraryHeader *)state->AmiSSLBase)->extBase;

    SHOWPOINTER(DBF_STARTUP, SysBase);
    SHOWPOINTER(DBF_STARTUP, __BASE_OR_IFACE_VAR);
    SHOWPOINTER(DBF_STARTUP, state->SocketBase);

    initialize_socket_errno(state);

    err = 0;
  }
  else
    err = 1;

  SHOWVALUE(DBF_STARTUP, err);

  return(err);
}

LIBPROTO(CleanupAmiSSLA, LONG, REG(a6, UNUSED __BASE_OR_IFACE), REG(a0, UNUSED struct TagItem *tagList))
{
  AMISSL_STATE *state;

  SHOWREGISTERS();

  if((state = GetAmiSSLState()))
  {
    OPENSSL_thread_stop();

    CleanupTimers(state);

#ifdef __amigaos4__
    if(state->SocketBase && state->ISocketPtr && *state->ISocketPtr)
    {
      DropInterface((struct Interface *)*state->ISocketPtr);
    }
#endif

    LOCK_OBTAIN(parentBase->openssl_cs);
    D(DBF_STARTUP, "h_delete(parentBase->thread_hash)");
    h_delete(parentBase->thread_hash, state->pid);
    LOCK_RELEASE(parentBase->openssl_cs);

    if(state->getenv_var)
      free(state->getenv_var);

    free(state);
  }

  return(0);
}

#ifdef __amigaos4__
LIBPROTOVA(InitAmiSSL, LONG, REG(a6, __BASE_OR_IFACE), ...)
{
  __gnuc_va_list ap;
  struct TagItem *tags;

  __builtin_va_start(ap, __BASE_OR_IFACE_VAR);
  tags = va_getlinearva(ap, struct TagItem *);
  __builtin_va_end(ap);

  return CALL_LFUNC(InitAmiSSLA, tags);
}

LIBPROTOVA(CleanupAmiSSL, LONG, REG(a6, __BASE_OR_IFACE), ...)
{
  __gnuc_va_list ap;
  struct TagItem *tags;

  __builtin_va_start(ap, __BASE_OR_IFACE_VAR);
  tags = va_getlinearva(ap, struct TagItem *);
  __builtin_va_end(ap);

  return LIB_CleanupAmiSSLA(__BASE_OR_IFACE_VAR, tags);
}
#endif

LIBPROTO(__UserLibCleanup, void, REG(a6, UNUSED __BASE_OR_IFACE), REG(a0, struct LibraryHeader *libBase))
{
  AMISSL_STATE *state;

  TRACELINE();

  // Skip OPENSSL_cleanup() + __free_libcmt() — they destroy global
  // state (provider, memory pool) shared across all library users.
  // Without proper reinit on next use, SSL_CTX_new fails or crashes.
  // Global state persists, which is fine on AmigaOS/AROS.
  // OPENSSL_cleanup();
  // CRYPTO_THREAD_cleanup();
  // __free_libcmt();

  if((state = GetAmiSSLState()))
    CleanupTimers(state);

  if(UtilityBase != NULL)
  {
    CloseLibrary((struct Library *)UtilityBase);
    UtilityBase = NULL;
  }
  if(IntuitionBase != NULL)
  {
    CloseLibrary((struct Library *)IntuitionBase);
    IntuitionBase = NULL;
  }
}

LIBPROTO(__UserLibExpunge, void, REG(a6, UNUSED __BASE_OR_IFACE))
{
  //TRACELINE();
}

LIBPROTO(__UserLibInit, int, REG(a6, __BASE_OR_IFACE), REG(a0, struct LibraryHeader *libBase))
{
  int err = 1; /* Assume error condition */

  ENTER();

  SHOWPOINTER(DBF_STARTUP, __BASE_OR_IFACE_VAR);
  SHOWPOINTER(DBF_STARTUP, libBase);
  SHOWPOINTER(DBF_STARTUP, libBase->parent);

  // lets set libBase as the ownBase for later reference
  ownBase = libBase;
  SHOWPOINTER(DBF_STARTUP, &ownBase);
  SHOWPOINTER(DBF_STARTUP, ownBase);

  // lets set the parent of libBase as our parentBase
  parentBase = libBase->parent;
  SHOWPOINTER(DBF_STARTUP, &parentBase);
  SHOWPOINTER(DBF_STARTUP, parentBase);

  // we have to initialize the libcmt stuff
  if (!__init_libcmt())
    return err;

  D(DBF_STARTUP, "Global parentBase variables:");
  D(DBF_STARTUP, "---------------------------");
  SHOWPOINTER(DBF_STARTUP, &parentBase->openssl_cs);
  SHOWPOINTER(DBF_STARTUP, &parentBase->thread_hash);
  SHOWPOINTER(DBF_STARTUP, parentBase->thread_hash);
  SHOWPOINTER(DBF_STARTUP, &parentBase->LastThreadGroupID);
  SHOWVALUE(DBF_STARTUP, parentBase->LastThreadGroupID);
  D(DBF_STARTUP, "---------------------------");

  LOCK_OBTAIN(parentBase->openssl_cs);

  ownBase->ThreadGroupID = ++(parentBase->LastThreadGroupID);
  SHOWPOINTER(DBF_STARTUP, &ownBase->ThreadGroupID);
  SHOWVALUE(DBF_STARTUP, ownBase->ThreadGroupID);

  LOCK_RELEASE(parentBase->openssl_cs);

  if (CRYPTO_THREAD_setup()
#if defined(__amigaos4__)
    && (IntuitionBase = OpenLibrary("intuition.library", 50))
    && (UtilityBase = OpenLibrary("utility.library", 50))
    && (IIntuition = (struct IntuitionIFace *)GetInterface(IntuitionBase,"main",1,NULL))
    && (IUtility = (struct UtilityIFace *)GetInterface(UtilityBase,"main",1,NULL)))
#else
    && (IntuitionBase = (struct IntuitionBase*)OpenLibrary("intuition.library", 36))
    && (UtilityBase = (struct UtilityBase *)OpenLibrary("utility.library", 37)))
#endif
  {
    err = 0;
  }

  D(DBF_STARTUP, "Userlib err: %d %08lx", err, SysBase);

  if (err != 0)
    CALL_LFUNC(__UserLibCleanup, libBase);

  RETURN(err);
  return(err);
}
